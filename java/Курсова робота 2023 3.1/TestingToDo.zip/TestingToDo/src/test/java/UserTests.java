import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserTests {
    WebDriver driver;
    @Before
    public void setUp() {
        System.setProperty("webdriver.firefox.driver", "C:\\Program Files\\Mozilla Firefox\\firefox.exe");
        driver = new FirefoxDriver();
    }

    @After
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void CreateUser() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/users/create");
        Thread.sleep(1000);
        WebElement nameField = driver.findElement(By.id("first-name"));
        nameField.sendKeys("Alexandra");
        WebElement lastnameField = driver.findElement(By.id("last-name"));
        lastnameField.sendKeys("Kyrylchuk");
        WebElement emailField = driver.findElement(By.id("email"));
        emailField.sendKeys("alex@mail.com");
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("1111");
        Thread.sleep(1000);
        WebElement submitButton = driver.findElement(By.id("register"));
        submitButton.click();
        Thread.sleep(1000);

        driver.get("http://localhost:8081/");
        List<WebElement> rows = driver.findElements(By.xpath("/html/body/div[2]/table/tbody"));

        for (WebElement row : rows) {
            WebElement titleElement = row.findElement(By.xpath(".//td[3]"));
            String titleText = titleElement.getText();

            if (titleText.equals("Alexandra Kyrylchuk")) {
                assertTrue(titleText.equals("Alexandra Kyrylchuk"));
            }
        }
    }

    @Test
    public void UpdateUser() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/users/6/update");
        Thread.sleep(1000);
        WebElement clearButton = driver.findElement(By.id("clear"));
        clearButton.click();

        WebElement nameField = driver.findElement(By.id("first-name"));
        nameField.sendKeys("edit");
        WebElement lastnameField = driver.findElement(By.id("last-name"));
        lastnameField.sendKeys("edit");
        WebElement oldpasswordField = driver.findElement(By.id("old-password"));
        oldpasswordField.sendKeys("3333");
        WebElement newpasswordField = driver.findElement(By.id("new-password"));
        newpasswordField.sendKeys("4444");
        Thread.sleep(1000);

        Select roleDropdown = new Select(driver.findElement(By.id("role")));
        roleDropdown.selectByVisibleText("User");
        Thread.sleep(1000);
        WebElement submitButton = driver.findElement(By.id("update"));
        submitButton.click();

        driver.get("http://localhost:8081/");
        List<WebElement> rows = driver.findElements(By.xpath("/html/body/div[2]/table/tbody"));

        for (WebElement row : rows) {
            WebElement titleElement = row.findElement(By.xpath(".//td[3]"));
            String titleText = titleElement.getText();

            if (titleText.equals("Noraedit Whiteedit")) {
                assertTrue(titleText.equals("Noraedit Whiteedit"));
            }
        }
    }

    @Test
    public void DeleteUser() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/");
        Thread.sleep(1000);
        WebElement deleteButton = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[3]/td[5]/a"));
        deleteButton.click();
        Thread.sleep(1000);
    }
}
