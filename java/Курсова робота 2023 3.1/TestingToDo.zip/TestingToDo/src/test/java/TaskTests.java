import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class TaskTests {
    WebDriver driver;
    @Before
    public void setUp() {
        System.setProperty("webdriver.firefox.driver", "C:\\Program Files\\Mozilla Firefox\\firefox.exe");
        driver = new FirefoxDriver();
    }

    @After
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void CreateTask() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/todos/8/tasks");
        Thread.sleep(1000);
        WebElement createButton = driver.findElement(By.id("create"));
        createButton.click();
        Thread.sleep(1000);
        WebElement nameField = driver.findElement(By.id("name"));
        nameField.sendKeys("New Task");
        WebElement submitButton = driver.findElement(By.id("create"));
        submitButton.click();
        Thread.sleep(1000);
        Select collaboratorDropdown = new Select(driver.findElement(By.id("users")));
        collaboratorDropdown.selectByVisibleText("Nick Green");
        WebElement addButton = driver.findElement(By.id("add"));
        addButton.click();
        Thread.sleep(1000);

        driver.get("http://localhost:8081/todos/8/tasks");
        WebElement getName = driver.findElement(By.xpath("/html/body/div[2]/table[1]/tbody/tr[2]/td[3]"));
        assertEquals("New Task", getName.getText());
    }

    @Test
    public void UpdateTask() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/tasks/7/update/todos/7");

        Thread.sleep(1000);
        WebElement titleField = driver.findElement(By.id("name"));
        titleField.sendKeys(" Edited");
        Select priorityDropdown = new Select(driver.findElement(By.id("priority")));
        priorityDropdown.selectByVisibleText("High");
        Select stateDropdown = new Select(driver.findElement(By.id("state")));
        stateDropdown.selectByVisibleText("Done");

        WebElement updateButton = driver.findElement(By.id("update"));
        updateButton.click();
        Thread.sleep(1000);

        List<WebElement> rows = driver.findElements(By.xpath("/html/body/div[2]/table[1]/tbody"));

        for (WebElement row : rows) {
            WebElement titleElement = row.findElement(By.xpath(".//td[3]"));
            String titleText = titleElement.getText();

            if (titleText.equals("Task #3 Edited")) {
                assertTrue(titleText.equals("Task #3 Edited"));
            }
        }
    }

    @Test
    public void DeleteTask() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/todos/7/tasks");
        Thread.sleep(1000);
        WebElement deleteButton = driver.findElement(By.xpath("/html/body/div[2]/table[1]/tbody/tr[2]/td[7]/a"));
        deleteButton.click();
        Thread.sleep(1000);
    }
}
