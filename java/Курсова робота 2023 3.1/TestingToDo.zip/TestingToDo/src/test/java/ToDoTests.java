import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.List;

import static org.junit.Assert.assertTrue;

public class ToDoTests {
    WebDriver driver;
    @Before
    public void setUp() {
        System.setProperty("webdriver.firefox.driver", "C:\\Program Files\\Mozilla Firefox\\firefox.exe");
        driver = new FirefoxDriver();
    }

    @After
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void CreateToDo() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/todos/all/users/4");
        Thread.sleep(1000);
        WebElement createButton = driver.findElement(By.id("create"));
        createButton.click();
        Thread.sleep(1000);
        WebElement titleField = driver.findElement(By.id("title"));
        titleField.sendKeys("New TODO");
        WebElement submitButton = driver.findElement(By.id("create"));
        submitButton.click();
        Thread.sleep(1000);
        driver.get("http://localhost:8081/todos/all/users/4");

        List<WebElement> rows = driver.findElements(By.xpath("/html/body/div[2]/table/tbody"));

        for (WebElement row : rows) {
            WebElement titleElement = row.findElement(By.xpath(".//td[3]"));
            String titleText = titleElement.getText();

            if (titleText.equals("NewTODO")) {
                assertTrue(titleText.equals("NewTODO"));
            }
        }
    }

    @Test
    public void UpdateToDo() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/todos/9/update/users/5");

        Thread.sleep(1000);
        WebElement titleField = driver.findElement(By.id("title"));
        titleField.sendKeys(" Edited");
        WebElement updateButton = driver.findElement(By.id("update"));
        updateButton.click();
        Thread.sleep(1000);

        List<WebElement> rows = driver.findElements(By.xpath("/html/body/div[2]/table/tbody"));

        for (WebElement row : rows) {
            WebElement titleElement = row.findElement(By.xpath(".//td[3]"));
            String titleText = titleElement.getText();

            if (titleText.equals("Mike's To-Do #3 Edited")) {
                assertTrue(titleText.equals("Mike's To-Do #3 Edited"));
            }
        }
    }

    @Test
    public void DeleteToDo() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("http://localhost:8081/todos/all/users/5");
        Thread.sleep(1000);
        WebElement deleteButton = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[2]/td[7]/a"));
        deleteButton.click();
        Thread.sleep(1000);
    }
}
