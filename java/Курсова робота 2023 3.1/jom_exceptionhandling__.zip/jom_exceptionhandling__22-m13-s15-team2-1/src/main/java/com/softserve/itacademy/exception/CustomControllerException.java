package com.softserve.itacademy.exception;

public class CustomControllerException extends RuntimeException{
    private String backLink;

    public CustomControllerException(String message, String backLink) {
        super(message);
        this.backLink = backLink;
    }

    public String getBackLink() {
        return backLink;
    }
}
