package com.softserve.itacademy.model;

public enum Priority {
    LOW, MEDIUM, HIGH
}
