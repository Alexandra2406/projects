package com.softserve.itacademy.service.impl;

import com.softserve.itacademy.exception.NullEntityReferenceException;
import com.softserve.itacademy.model.Role;
import com.softserve.itacademy.repository.RoleRepository;
import com.softserve.itacademy.service.RoleService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class RoleServiceImpl implements RoleService {
    private Logger logger = Logger.getLogger(RoleServiceImpl.class.getName());
    private RoleRepository roleRepository;

    public RoleServiceImpl(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public Role create(Role role) {
        try {
            logger.info("Creating Role");
            return roleRepository.save(role);
        } catch (IllegalArgumentException e) {
            logger.warning("Role == Null");
            throw new NullEntityReferenceException("Role cannot be 'null'");
        }
    }

    @Override
    public Role readById(long id) {
        logger.info("Reading Role By Id");
        Optional<Role> optional = roleRepository.findById(id);
        return optional.get();
    }

    @Override
    public Role update(Role role) {
        if (role != null) {
            Role oldRole = readById(role.getId());
            if (oldRole != null) {
                logger.info("Updating Role");
                return roleRepository.save(role);
            }
            logger.warning("Old Role == Null");
        }
        logger.warning("Role == Null");
        throw new NullEntityReferenceException("Role cannot be 'null'");
    }

    @Override
    public void delete(long id) {
        Role role = readById(id);
        if (role != null) {
            logger.info("Deleting Role");
            roleRepository.delete(role);
        } else {
            logger.warning("Role == Null");
            throw new NullEntityReferenceException("Role cannot be 'null'");
        }
    }

    @Override
    public List<Role> getAll() {
        logger.info("Getting All Roles");
        List<Role> roles = roleRepository.findAll();
        return roles.isEmpty() ? new ArrayList<>() : roles;
    }
}
