package com.softserve.itacademy.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.persistence.EntityNotFoundException;

@ControllerAdvice
public class ApplicationExceptionHandler {

    Logger logger = LoggerFactory.getLogger(ApplicationExceptionHandler.class);

    @ExceptionHandler(CustomControllerException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    public ModelAndView handleException(CustomControllerException exception) {
        logger.error("CustomControllerException thrown");
        ModelAndView modelAndView = new ModelAndView("error-page", HttpStatus.BAD_REQUEST);
        modelAndView.addObject("errorInfo", exception.getMessage());
        modelAndView.addObject("backLink", exception.getBackLink());
        return modelAndView;
    }

    @ExceptionHandler(NullEntityReferenceException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ModelAndView handleNullEntityReferenceException(NullEntityReferenceException exception) {
        logger.error("NullEntityReferenceException thrown");
        ModelAndView modelAndView = new ModelAndView("500-page" , HttpStatus.INTERNAL_SERVER_ERROR);
        modelAndView.addObject("errorInfo", exception.getMessage());
        return modelAndView;
    }

    @ExceptionHandler(EntityNotFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public ModelAndView handleEntityNotFoundException(EntityNotFoundException exception) {
        logger.error("EntityNotFoundException thrown");
        ModelAndView modelAndView = new ModelAndView("error", HttpStatus.NOT_FOUND);
        if (exception.getMessage() != null) {
            modelAndView.addObject("errorInfo", exception.getMessage());
        } else {
            modelAndView.addObject("errorInfo", "Entered invalid href");
        }
        return modelAndView;
    }
}
