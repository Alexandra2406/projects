package com.softserve.itacademy.service.impl;

import com.softserve.itacademy.exception.NullEntityReferenceException;
import com.softserve.itacademy.model.Task;
import com.softserve.itacademy.repository.TaskRepository;
import com.softserve.itacademy.service.TaskService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class TaskServiceImpl implements TaskService {
    private Logger logger = Logger.getLogger(TaskServiceImpl.class.getName());
    private TaskRepository taskRepository;

    public TaskServiceImpl(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    @Override
    public Task create(Task task) {
        try {
            logger.info("Creating Task");
            return taskRepository.save(task);
        } catch (RuntimeException e) {
            logger.warning("Task == Null");
            throw new NullEntityReferenceException("Task cannot be 'null'");
        }
    }

    @Override
    public Task readById(long id) {
        Optional<Task> optional = taskRepository.findById(id);
        if (optional.isPresent()) {
            logger.info("Reading Task by id");
            return optional.get();
        }
        logger.warning("Task with id " + id + " not found");
        throw new EntityNotFoundException("Task with id " + id + " not found");
    }

    @Override
    public Task update(Task task) {
        if (task != null && task.getName() != "") {
            Task oldTask = readById(task.getId());
            if (oldTask != null && oldTask.getName() != "") {
                logger.info("Updating Task");
                return taskRepository.save(task);
            }
            logger.warning("OldTask == null");
        }
        logger.warning("Task == Null");
        throw new NullEntityReferenceException("Task cannot be 'null'");
    }

    @Override
    public void delete(long id) {
        Task task = readById(id);
        if (task != null) {
            logger.info("Deleting Task");
            taskRepository.delete(task);
        } else {
            logger.warning("Task with id " + id + " not found");
            throw new EntityNotFoundException("Task with id " + id + " not found");
        }
    }

    @Override
    public List<Task> getAll() {
        logger.info("Getting All Tasks");
        List<Task> tasks = taskRepository.findAll();
        return tasks.isEmpty() ? new ArrayList<>() : tasks;
    }

    @Override
    public List<Task> getByTodoId(long todoId) {
        logger.info("Getting Task By ToDo Id");
        List<Task> tasks = taskRepository.getByTodoId(todoId);
        return tasks.isEmpty() ? new ArrayList<>() : tasks;
    }
}
