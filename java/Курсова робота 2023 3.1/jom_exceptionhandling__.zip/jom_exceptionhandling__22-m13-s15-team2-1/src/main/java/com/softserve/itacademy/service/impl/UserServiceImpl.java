package com.softserve.itacademy.service.impl;

import com.softserve.itacademy.controller.UserController;
import com.softserve.itacademy.exception.NullEntityReferenceException;
import com.softserve.itacademy.model.User;
import com.softserve.itacademy.repository.UserRepository;
import com.softserve.itacademy.service.UserService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class UserServiceImpl implements UserService {
    private Logger logger = Logger.getLogger(UserServiceImpl.class.getName());
    private UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User create(User user) {
        try {
            logger.info("Creating User");
            return userRepository.save(user);
        } catch (RuntimeException e) {
            logger.warning("User == null");
            throw new NullEntityReferenceException("User cannot be 'null'");
        }
    }

    @Override
    public User readById(long id) {
        Optional<User> optional = userRepository.findById(id);
        if (optional.isPresent()) {
            logger.info("Reading User by id");
            return optional.get();
        }
        logger.warning("User with id " + id + " not found");
        throw new EntityNotFoundException("User with id " + id + " not found");
    }

    @Override
    public User update(User user) {
        if (user != null && user.getFirstName() != "" && user.getLastName() != "") {
            User oldUser = readById(user.getId());
            if (oldUser != null && oldUser.getFirstName() != "" && oldUser.getLastName() != "") {
                logger.info("Updating User");
                return userRepository.save(user);
            }
            logger.warning("OldUser == null");
        }
        logger.warning("User == null");
        throw new NullEntityReferenceException("User cannot be 'null'");
    }

    @Override
    public void delete(long id) {
        User user = readById(id);
        if (user != null) {
            logger.info("Deleting user");
            userRepository.delete(user);
        } else {
            logger.warning("User with id " + id + " not found");
            throw new EntityNotFoundException("User with id " + id + " not found");
        }
    }

    @Override
    public List<User> getAll() {
        logger.info("Getting all users");
        List<User> users = userRepository.findAll();
        return users.isEmpty() ? new ArrayList<>() : users;
    }

}
