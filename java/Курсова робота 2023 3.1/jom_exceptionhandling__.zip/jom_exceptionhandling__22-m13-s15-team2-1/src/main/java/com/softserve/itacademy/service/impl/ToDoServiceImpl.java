package com.softserve.itacademy.service.impl;

import com.softserve.itacademy.controller.ToDoController;
import com.softserve.itacademy.exception.NullEntityReferenceException;
import com.softserve.itacademy.model.ToDo;
import com.softserve.itacademy.repository.ToDoRepository;
import com.softserve.itacademy.service.ToDoService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

@Service
public class ToDoServiceImpl implements ToDoService {
    private Logger logger = Logger.getLogger(ToDoServiceImpl.class.getName());
    private ToDoRepository todoRepository;

    public ToDoServiceImpl(ToDoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    @Override
    public ToDo create(ToDo todo) {
        try{
            logger.info("Creating ToDo");
            return todoRepository.save(todo);
        } catch (RuntimeException e){
            logger.warning("ToDo == null");
            throw new NullEntityReferenceException("To-Do title cannot be 'null'");
        }
    }

    @Override
    public ToDo readById(long id) {
        Optional<ToDo> optional = todoRepository.findById(id);
        if (optional.isPresent()) {
            logger.info("Reading ToDo by id");
            return optional.get();
        }
        logger.warning("ToDo with id " + id + " not found");
        throw new EntityNotFoundException("To-Do with id " + id + " not found");
    }

    @Override
    public ToDo update(ToDo todo) {
        if (todo != null && todo.getTitle() != "") {
            ToDo oldTodo = readById(todo.getId());
            if (oldTodo != null && oldTodo.getTitle() != "") {
                logger.info("Updating ToDo");
                return todoRepository.save(todo);
            }
        }
        throw new NullEntityReferenceException("To-Do title cannot be 'null'");
    }

    @Override
    public void delete(long id) {
        ToDo todo = readById(id);
        if (todo != null) {
            logger.info("Deleting ToDo");
            todoRepository.delete(todo);
        } else {
            throw new EntityNotFoundException("To-Do with id " + id + " not found");
        }
    }

    @Override
    public List<ToDo> getAll() {
        logger.info("Getting all ToDo");
        List<ToDo> todos = todoRepository.findAll();
        return todos.isEmpty() ? new ArrayList<>() : todos;
    }

    @Override
    public List<ToDo> getByUserId(long userId) {
        logger.info("Getting ToDo by User id");
        List<ToDo> todos = todoRepository.getByUserId(userId);
        return todos.isEmpty() ? new ArrayList<>() : todos;
    }
}
